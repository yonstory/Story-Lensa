package com.yon.lensaempat;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.MeteringRectangle;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.ExifInterface;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaActionSound;
import android.net.Uri;
import android.opengl.GLSurfaceView;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Range;
import android.util.Rational;
import android.util.Size;
import android.util.SizeF;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.OrientationEventListener;
import android.view.Surface;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_CAMERA = 1;
    static final String VERSION = "v4";

    private WebView web;
    private GLSurfaceView glView;
    private final Handler main = new Handler(Looper.getMainLooper());
    private HandlerThread camThread;
    private Handler camH;
    private Processor proc;
    private CameraManager cm;
    private MediaActionSound sound;
    private OrientationEventListener orientationListener;

    // Camera state (touched on camH only, unless volatile)
    private CameraDevice device;
    private CameraCaptureSession session;
    private ImageReader jpegReader;
    private Surface previewSurface;
    private String camId;
    private boolean front = false;
    private Size previewSize = new Size(1440, 1080);
    private Size jpegSize = new Size(4000, 3000);
    private int sensorOri = 90;
    private float camZoomMin = 1f, camZoomMax = 1f;
    private boolean zoomRatioApi = false;
    private Rect activeArray;
    private boolean afContinuous = false;
    private List<Lens> lenses = new ArrayList<>();
    private int lensIdx = 0;
    private float pinch = 1f;
    private int openGen = 0;
    private float mainMm = 24f;
    private final ArrayDeque<Shot> pendingShots = new ArrayDeque<>();

    // Exposure / focus / pro controls
    private boolean hasFlash = false;
    private int flashMode = 0; // 0 off, 1 auto, 2 on
    private Range<Integer> evRange;
    private float evStep = 1f / 3f;
    private float evValue = 0f;
    private boolean aeAfLock = false;
    private MeteringRectangle[] regions = null;
    private int maxAf = 0, maxAe = 0;
    private boolean manualSensor = false;
    private Range<Integer> isoRange;
    private Range<Long> expRange;
    private float minFocus = 0f;
    private int[] awbModes = new int[0];
    private int manualIso = 0;
    private long manualExp = 0;
    private int awbMode = CaptureRequest.CONTROL_AWB_MODE_AUTO;
    private float manualFocus = -1f;
    private int lastIso = 200;
    private long lastExp = 16_666_666L;
    private long lastMeterEmit = 0;
    private final Runnable regionReset = () -> {
        if (aeAfLock) return;
        regions = null;
        updateRepeating();
        emit("focusReset", "{}");
    };
    private boolean precapturing = false;
    private boolean precaptureSeen = false;
    private int precaptureFrames = 0;
    private String precaptureName = null;
    private final Runnable precaptureTimeout = () -> finishPrecapture();

    volatile SurfaceTexture surfaceTexture;
    volatile Look look = Look.identity();
    volatile boolean showOriginal = false;
    volatile float[] vfRect = null; // x, y, w, h, radius in px
    volatile float bufAspect = 0.75f; // upright width / height of preview buffer
    volatile boolean camReady = false;
    volatile int deviceOri = 0;
    private boolean resumed = false;

    static class Lens {
        String camId; float zoom; float display; float camMax;
        Lens(String id, float z, float d, float max) { camId = id; zoom = z; display = d; camMax = max; }
        String label() {
            if (display < 1f) return String.format(java.util.Locale.US, "%.1f", display);
            float r = Math.round(display);
            return Math.abs(display - r) < 0.15f ? String.valueOf((int) r) : String.format(java.util.Locale.US, "%.1f", display);
        }
    }

    static class Shot {
        String name; Look look; boolean front; Shot(String n, Look l, boolean f) { name = n; look = l; front = f; }
    }

    static class CamInfo {
        String id; int facing; double eq; float zMin = 1f, zMax = 1f;
    }

    // ===================== Lifecycle =====================
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        cm = (CameraManager) getSystemService(CAMERA_SERVICE);
        camThread = new HandlerThread("cam");
        camThread.start();
        camH = new Handler(camThread.getLooper());
        proc = new Processor();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        glView = new GLSurfaceView(this);
        glView.setEGLContextClientVersion(2);
        glView.setPreserveEGLContextOnPause(true);
        glView.setRenderer(new PreviewRenderer());
        glView.setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);
        root.addView(glView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        web = new WebView(this);
        web.setBackgroundColor(Color.TRANSPARENT);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        web.loadUrl("file:///android_asset/index.html");

        sound = new MediaActionSound();
        sound.load(MediaActionSound.SHUTTER_CLICK);
        sound.load(MediaActionSound.FOCUS_COMPLETE);

        orientationListener = new OrientationEventListener(this) {
            @Override
            public void onOrientationChanged(int o) {
                if (o == ORIENTATION_UNKNOWN) return;
                deviceOri = ((o + 45) / 90 * 90) % 360;
            }
        };

        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        glView.onResume();
        if (orientationListener.canDetectOrientation()) orientationListener.enable();
        if (surfaceTexture != null) startCameraIfReady();
    }

    @Override
    protected void onPause() {
        resumed = false;
        orientationListener.disable();
        camH.post(this::closeCamera);
        glView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        camH.post(this::closeCamera);
        camThread.quitSafely();
        proc.quit();
        sound.release();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_CAMERA) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startCameraIfReady();
            else emit("denied", "{}");
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            if (event.getRepeatCount() == 0) emit("key", "{}");
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void emit(String type, String json) {
        final String js = "window.__storyEvent&&window.__storyEvent(" + JSONObject.quote(type) + "," + json + ")";
        main.post(() -> web.evaluateJavascript(js, null));
    }

    // ===================== Camera discovery =====================
    private CamInfo info(String id) throws CameraAccessException {
        CameraCharacteristics ch = cm.getCameraCharacteristics(id);
        CamInfo ci = new CamInfo();
        ci.id = id;
        Integer f = ch.get(CameraCharacteristics.LENS_FACING);
        ci.facing = f == null ? -1 : f;
        float[] fl = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
        SizeF size = ch.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);
        if (fl != null && fl.length > 0 && size != null) {
            double diag = Math.hypot(size.getWidth(), size.getHeight());
            if (diag > 0) ci.eq = fl[0] * 43.27 / diag;
        }
        if (Build.VERSION.SDK_INT >= 30) {
            Range<Float> r = ch.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE);
            if (r != null) { ci.zMin = r.getLower(); ci.zMax = r.getUpper(); }
        }
        if (ci.zMax <= 1f) {
            Float md = ch.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
            ci.zMin = 1f;
            ci.zMax = md == null ? 1f : md;
        }
        return ci;
    }

    private List<Lens> buildLenses(boolean wantFront) {
        List<Lens> out = new ArrayList<>();
        try {
            int want = wantFront ? CameraCharacteristics.LENS_FACING_FRONT : CameraCharacteristics.LENS_FACING_BACK;
            CamInfo mainCam = null;
            List<CamInfo> others = new ArrayList<>();
            for (String id : cm.getCameraIdList()) {
                CamInfo ci = info(id);
                if (ci.facing != want) continue;
                if (mainCam == null) mainCam = ci; else others.add(ci);
            }
            if (mainCam == null) return out;
            float mainMax = Math.min(mainCam.zMax, 20f);
            double mEq = mainCam.eq;
            mainMm = mEq > 0 ? (float) mEq : 24f;

            if (mainCam.zMin < 0.95f) {
                out.add(new Lens(mainCam.id, mainCam.zMin, mainCam.zMin, mainMax));
            } else if (mEq > 0) {
                CamInfo uw = null;
                for (CamInfo o : others) if (o.eq > 0 && o.eq < mEq * 0.8 && (uw == null || o.eq < uw.eq)) uw = o;
                if (uw != null) out.add(new Lens(uw.id, 1f, (float) (uw.eq / mEq), Math.min(uw.zMax, 4f)));
            }
            out.add(new Lens(mainCam.id, 1f, 1f, mainMax));

            List<Lens> teles = new ArrayList<>();
            if (mEq > 0) {
                List<CamInfo> sorted = new ArrayList<>(others);
                Collections.sort(sorted, (a, b) -> Double.compare(a.eq, b.eq));
                for (CamInfo o : sorted) {
                    if (o.eq <= mEq * 1.5) continue;
                    float r = (float) (o.eq / mEq);
                    boolean dup = false;
                    for (Lens t : teles) if (Math.abs(t.display - r) < 0.4f) dup = true;
                    if (!dup) teles.add(new Lens(o.id, 1f, r, Math.min(o.zMax, 10f)));
                }
            }
            boolean has2 = false;
            for (Lens t : teles) if (t.display > 1.7f && t.display < 2.4f) has2 = true;
            if (!has2 && mainMax >= 2f) out.add(new Lens(mainCam.id, 2f, 2f, mainMax));
            out.addAll(teles);
            if (teles.isEmpty()) {
                if (mainMax >= 4f && mainMax < 10f) out.add(new Lens(mainCam.id, 4f, 4f, mainMax));
                if (mainMax >= 10f) { out.add(new Lens(mainCam.id, 4f, 4f, mainMax)); out.add(new Lens(mainCam.id, 10f, 10f, mainMax)); }
            }
            Collections.sort(out, (a, b) -> Float.compare(a.display, b.display));
        } catch (Exception ignored) {
        }
        return out;
    }

    private int mainLensIndex() {
        for (int i = 0; i < lenses.size(); i++) if (lenses.get(i).display == 1f) return i;
        return 0;
    }

    private void startCameraIfReady() {
        if (!resumed || surfaceTexture == null) return;
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
        camH.post(() -> {
            if (lenses.isEmpty()) {
                lenses = buildLenses(front);
                lensIdx = mainLensIndex();
                pinch = 1f;
            }
            if (lenses.isEmpty()) { emit("error", "{\"msg\":\"Kamera tidak ditemukan\"}"); return; }
            openCamera(lenses.get(lensIdx).camId);
        });
    }

    private static Size pick(Size[] sizes, long maxPixels, int maxW, boolean need43) {
        Size best = null;
        if (sizes == null) return null;
        for (Size s : sizes) {
            long px = (long) s.getWidth() * s.getHeight();
            if (px > maxPixels || s.getWidth() > maxW) continue;
            if (need43 && s.getWidth() * 3 != s.getHeight() * 4) continue;
            if (best == null || px > (long) best.getWidth() * best.getHeight()) best = s;
        }
        return best;
    }

    // ===================== Camera open / session (camH only) =====================
    private void openCamera(String id) {
        closeCamera();
        final int gen = ++openGen;
        try {
            CameraCharacteristics ch = cm.getCameraCharacteristics(id);
            StreamConfigurationMap map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map == null) throw new IllegalStateException("no map");
            Size[] prevSizes = map.getOutputSizes(SurfaceTexture.class);
            Size p = pick(prevSizes, 1920L * 1440L, 1920, true);
            if (p == null) p = pick(prevSizes, 1920L * 1080L, 1920, false);
            if (p != null) previewSize = p;
            Size[] jpgSizes = map.getOutputSizes(ImageFormat.JPEG);
            Size j = pick(jpgSizes, 13_000_000L, 100000, true);
            if (j == null) j = pick(jpgSizes, 13_000_000L, 100000, false);
            if (j != null) jpegSize = j;
            Integer so = ch.get(CameraCharacteristics.SENSOR_ORIENTATION);
            sensorOri = so == null ? 90 : so;
            CamInfo ci = info(id);
            camZoomMin = ci.zMin;
            camZoomMax = ci.zMax;
            zoomRatioApi = false;
            if (Build.VERSION.SDK_INT >= 30) zoomRatioApi = ch.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE) != null;
            activeArray = ch.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
            int[] afModes = ch.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES);
            afContinuous = false;
            if (afModes != null) for (int m : afModes) if (m == CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE) afContinuous = true;
            Boolean fl = ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
            hasFlash = fl != null && fl;
            evRange = ch.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE);
            Rational step = ch.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP);
            evStep = step == null || step.floatValue() <= 0 ? 1f / 3f : step.floatValue();
            Integer ma = ch.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF);
            Integer me = ch.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE);
            maxAf = ma == null ? 0 : ma;
            maxAe = me == null ? 0 : me;
            int[] caps = ch.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
            manualSensor = false;
            if (caps != null) for (int c : caps) if (c == CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR) manualSensor = true;
            isoRange = ch.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);
            expRange = ch.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE);
            if (isoRange == null || expRange == null) manualSensor = false;
            Float mf = ch.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE);
            minFocus = mf == null ? 0f : mf;
            int[] awb = ch.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES);
            awbModes = awb == null ? new int[0] : awb;
            boolean awbOk = false;
            for (int m : awbModes) if (m == awbMode) awbOk = true;
            if (!awbOk) awbMode = CaptureRequest.CONTROL_AWB_MODE_AUTO;
            regions = null;
            aeAfLock = false;
            evValue = 0f;
            manualFocus = -1f;
            if (!manualSensor) { manualIso = 0; manualExp = 0; }
            else {
                if (manualIso > 0) manualIso = isoRange.clamp(manualIso);
                if (manualExp > 0) manualExp = expRange.clamp(manualExp);
            }
            boolean rotated = sensorOri % 180 != 0;
            bufAspect = rotated ? (float) previewSize.getHeight() / previewSize.getWidth()
                    : (float) previewSize.getWidth() / previewSize.getHeight();
            camId = id;
            cm.openCamera(id, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(CameraDevice d) {
                    if (gen != openGen) { d.close(); return; }
                    device = d;
                    createSession(gen);
                }

                @Override
                public void onDisconnected(CameraDevice d) {
                    d.close();
                    if (device == d) { device = null; camReady = false; }
                }

                @Override
                public void onError(CameraDevice d, int error) {
                    d.close();
                    if (device == d || device == null) { device = null; camReady = false; }
                    if (gen == openGen) fallbackToMain();
                }
            }, camH);
        } catch (SecurityException se) {
            emit("denied", "{}");
        } catch (Exception e) {
            fallbackToMain();
        }
    }

    private void fallbackToMain() {
        int m = mainLensIndex();
        if (!lenses.isEmpty() && lensIdx != m) {
            lensIdx = m;
            pinch = 1f;
            emit("error", "{\"msg\":\"Lensa ini tidak bisa dibuka, kembali ke 1×\"}");
            openCamera(lenses.get(m).camId);
        } else {
            emit("error", "{\"msg\":\"Kamera tidak bisa dibuka\"}");
        }
    }

    private void createSession(final int gen) {
        try {
            SurfaceTexture st = surfaceTexture;
            if (st == null || device == null) return;
            st.setDefaultBufferSize(previewSize.getWidth(), previewSize.getHeight());
            previewSurface = new Surface(st);
            jpegReader = ImageReader.newInstance(jpegSize.getWidth(), jpegSize.getHeight(), ImageFormat.JPEG, 3);
            jpegReader.setOnImageAvailableListener(this::onJpeg, camH);
            device.createCaptureSession(Arrays.asList(previewSurface, jpegReader.getSurface()),
                    new CameraCaptureSession.StateCallback() {
                        @Override
                        public void onConfigured(CameraCaptureSession s) {
                            if (gen != openGen || device == null) { s.close(); return; }
                            session = s;
                            camReady = true;
                            updateRepeating();
                            sendCameraEvent();
                        }

                        @Override
                        public void onConfigureFailed(CameraCaptureSession s) {
                            if (gen == openGen) fallbackToMain();
                        }
                    }, camH);
        } catch (Exception e) {
            fallbackToMain();
        }
    }

    // ===================== Requests =====================
    private void applyZoom(CaptureRequest.Builder b) {
        if (lenses.isEmpty()) return;
        Lens l = lenses.get(lensIdx);
        float z = l.camId.equals(camId) ? l.zoom * pinch : pinch;
        z = Math.max(camZoomMin, Math.min(camZoomMax, z));
        if (zoomRatioApi && Build.VERSION.SDK_INT >= 30) {
            b.set(CaptureRequest.CONTROL_ZOOM_RATIO, z);
        } else if (activeArray != null) {
            b.set(CaptureRequest.SCALER_CROP_REGION, cropRegion(z));
        }
    }

    private Rect cropRegion(float z) {
        float zz = Math.max(1f, z);
        int aw = activeArray.width(), ah = activeArray.height();
        int w = (int) (aw / zz), h = (int) (ah / zz);
        int x = (aw - w) / 2, y = (ah - h) / 2;
        return new Rect(x, y, x + w, y + h);
    }

    private float currentZoom() {
        if (lenses.isEmpty()) return 1f;
        Lens l = lenses.get(lensIdx);
        float z = l.camId.equals(camId) ? l.zoom * pinch : pinch;
        return Math.max(camZoomMin, Math.min(camZoomMax, z));
    }

    private boolean manualExposure() {
        return manualSensor && (manualIso > 0 || manualExp > 0);
    }

    private void applyControls(CaptureRequest.Builder b) {
        applyZoom(b);
        b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
        if (manualExposure()) {
            b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF);
            int iso = manualIso > 0 ? manualIso : isoRange.clamp(lastIso);
            long exp = manualExp > 0 ? manualExp : expRange.clamp(lastExp);
            b.set(CaptureRequest.SENSOR_SENSITIVITY, iso);
            b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, exp);
            b.set(CaptureRequest.SENSOR_FRAME_DURATION, Math.max(exp, 33_333_333L));
            b.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_OFF);
        } else {
            int ae = CaptureRequest.CONTROL_AE_MODE_ON;
            if (hasFlash && flashMode == 1) ae = CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH;
            if (hasFlash && flashMode == 2) ae = CaptureRequest.CONTROL_AE_MODE_ON_ALWAYS_FLASH;
            b.set(CaptureRequest.CONTROL_AE_MODE, ae);
            if (evRange != null) {
                int idx = Math.round(evValue / evStep);
                b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, evRange.clamp(idx));
            }
            b.set(CaptureRequest.CONTROL_AE_LOCK, aeAfLock);
            if (regions != null && maxAe > 0) b.set(CaptureRequest.CONTROL_AE_REGIONS, regions);
        }
        if (manualFocus >= 0f && minFocus > 0f) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF);
            b.set(CaptureRequest.LENS_FOCUS_DISTANCE, manualFocus * minFocus);
        } else if (regions != null && maxAf > 0) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO);
            b.set(CaptureRequest.CONTROL_AF_REGIONS, regions);
        } else if (afContinuous) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
        }
        b.set(CaptureRequest.CONTROL_AWB_MODE, awbMode);
    }

    private CaptureRequest.Builder previewBuilder() throws CameraAccessException {
        CaptureRequest.Builder b = device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
        b.addTarget(previewSurface);
        applyControls(b);
        return b;
    }

    private void updateRepeating() {
        if (session == null || device == null || previewSurface == null) return;
        try {
            session.setRepeatingRequest(previewBuilder().build(), repeatCb, camH);
        } catch (Exception ignored) {
        }
    }

    private final CameraCaptureSession.CaptureCallback repeatCb = new CameraCaptureSession.CaptureCallback() {
        @Override
        public void onCaptureCompleted(CameraCaptureSession s, CaptureRequest r, TotalCaptureResult res) {
            Integer iso = res.get(CaptureResult.SENSOR_SENSITIVITY);
            Long ex = res.get(CaptureResult.SENSOR_EXPOSURE_TIME);
            if (iso != null) lastIso = iso;
            if (ex != null) lastExp = ex;
            if (precapturing) {
                precaptureFrames++;
                Integer ae = res.get(CaptureResult.CONTROL_AE_STATE);
                if (ae != null && ae == CaptureResult.CONTROL_AE_STATE_PRECAPTURE) precaptureSeen = true;
                boolean settled = ae == null || ae == CaptureResult.CONTROL_AE_STATE_CONVERGED
                        || ae == CaptureResult.CONTROL_AE_STATE_FLASH_REQUIRED || ae == CaptureResult.CONTROL_AE_STATE_LOCKED;
                if ((precaptureSeen && settled) || precaptureFrames > 20) finishPrecapture();
            }
            long now = SystemClock.uptimeMillis();
            if (now - lastMeterEmit > 300) {
                lastMeterEmit = now;
                emit("meter", "{\"iso\":" + lastIso + ",\"exp\":" + lastExp + "}");
            }
        }
    };

    private void sendCameraEvent() {
        try {
            JSONObject o = new JSONObject();
            o.put("front", front);
            o.put("aspect", bufAspect);
            o.put("lensIdx", lensIdx);
            o.put("mm", mainMm);
            JSONArray arr = new JSONArray();
            for (Lens l : lenses) {
                JSONObject j = new JSONObject();
                j.put("label", l.label());
                j.put("display", l.display);
                j.put("maxPinch", Math.max(1f, l.camMax / l.zoom));
                arr.put(j);
            }
            o.put("lenses", arr);
            o.put("flash", hasFlash);
            if (evRange != null) {
                o.put("evMin", evRange.getLower() * evStep);
                o.put("evMax", evRange.getUpper() * evStep);
                o.put("evStep", evStep);
            }
            o.put("focus", maxAf > 0 || maxAe > 0);
            o.put("manual", manualSensor);
            if (manualSensor) {
                o.put("isoMin", isoRange.getLower());
                o.put("isoMax", isoRange.getUpper());
                o.put("expMin", expRange.getLower());
                o.put("expMax", expRange.getUpper());
            }
            o.put("mf", manualSensor && minFocus > 0f);
            JSONArray wb = new JSONArray();
            for (int m : awbModes) wb.put(m);
            o.put("wb", wb);
            o.put("version", VERSION);
            emit("camera", o.toString());
        } catch (Exception ignored) {
        }
    }

    private void closeCamera() {
        openGen++;
        camReady = false;
        camH.removeCallbacks(regionReset);
        camH.removeCallbacks(precaptureTimeout);
        precapturing = false;
        try { if (session != null) session.close(); } catch (Exception ignored) { }
        session = null;
        try { if (device != null) device.close(); } catch (Exception ignored) { }
        device = null;
        try { if (jpegReader != null) jpegReader.close(); } catch (Exception ignored) { }
        jpegReader = null;
        if (previewSurface != null) previewSurface.release();
        previewSurface = null;
        pendingShots.clear();
    }

    // ===================== Focus & metering =====================
    private void focusAt(float nx, float ny) {
        if (session == null || device == null || activeArray == null) return;
        float[] c = cropFor(bufAspect, look.ta);
        float ux = c[0] + nx * c[2];
        float uy = 1f - (c[1] + (1f - ny) * c[3]);
        if (front) ux = 1f - ux;
        float sx, sy;
        switch (sensorOri) {
            case 90: sx = uy; sy = 1f - ux; break;
            case 270: sx = 1f - uy; sy = ux; break;
            case 180: sx = 1f - ux; sy = 1f - uy; break;
            default: sx = ux; sy = uy;
        }
        Rect base = zoomRatioApi ? new Rect(0, 0, activeArray.width(), activeArray.height()) : cropRegion(currentZoom());
        int half = (int) (Math.min(base.width(), base.height()) * 0.07f);
        int cx = base.left + (int) (sx * base.width()), cy = base.top + (int) (sy * base.height());
        int l = Math.max(base.left, cx - half), t = Math.max(base.top, cy - half);
        int r = Math.min(base.right - 1, cx + half), b = Math.min(base.bottom - 1, cy + half);
        if (r <= l || b <= t) return;
        regions = new MeteringRectangle[]{new MeteringRectangle(new Rect(l, t, r, b), MeteringRectangle.METERING_WEIGHT_MAX - 1)};
        aeAfLock = false;
        evValue = 0f;
        manualFocus = -1f;
        camH.removeCallbacks(regionReset);
        try {
            CaptureRequest.Builder cancel = previewBuilder();
            cancel.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_CANCEL);
            session.capture(cancel.build(), null, camH);
            CaptureRequest.Builder start = previewBuilder();
            start.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_START);
            session.capture(start.build(), null, camH);
        } catch (Exception ignored) {
        }
        updateRepeating();
        camH.postDelayed(regionReset, 8000);
    }

    // ===================== Capture =====================
    private int jpegOrientation() {
        return front ? (sensorOri - deviceOri + 360) % 360 : (sensorOri + deviceOri) % 360;
    }

    private void capture(String name) {
        if (session == null || device == null || jpegReader == null) {
            emit("saved", "{\"ok\":false}");
            return;
        }
        if (precapturing) return;
        if (hasFlash && flashMode != 0 && !manualExposure()) {
            try {
                precapturing = true;
                precaptureSeen = false;
                precaptureFrames = 0;
                precaptureName = name;
                CaptureRequest.Builder b = previewBuilder();
                b.set(CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER, CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER_START);
                session.capture(b.build(), null, camH);
                camH.postDelayed(precaptureTimeout, 1500);
                return;
            } catch (Exception e) {
                precapturing = false;
            }
        }
        still(name);
    }

    private void finishPrecapture() {
        if (!precapturing) return;
        precapturing = false;
        camH.removeCallbacks(precaptureTimeout);
        String n = precaptureName;
        precaptureName = null;
        if (n != null) still(n);
    }

    private void still(String name) {
        if (session == null || device == null || jpegReader == null) {
            emit("saved", "{\"ok\":false}");
            return;
        }
        try {
            CaptureRequest.Builder b = device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            b.addTarget(jpegReader.getSurface());
            b.addTarget(previewSurface);
            applyControls(b);
            b.set(CaptureRequest.JPEG_ORIENTATION, jpegOrientation());
            b.set(CaptureRequest.JPEG_QUALITY, (byte) 95);
            pendingShots.add(new Shot(name, look, front));
            session.capture(b.build(), null, camH);
            sound.play(MediaActionSound.SHUTTER_CLICK);
            emit("shutter", "{}");
        } catch (Exception e) {
            emit("saved", "{\"ok\":false}");
        }
    }

    private void onJpeg(ImageReader reader) {
        Image img = null;
        try {
            img = reader.acquireNextImage();
            if (img == null) return;
            java.nio.ByteBuffer bb = img.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[bb.remaining()];
            bb.get(bytes);
            Shot s = pendingShots.poll();
            if (s == null) s = new Shot("StoryLensa_" + System.currentTimeMillis() + ".jpg", look, front);
            proc.submit(bytes, s);
        } catch (Exception e) {
            emit("saved", "{\"ok\":false}");
        } finally {
            if (img != null) img.close();
        }
        if (hasFlash && flashMode != 0) updateRepeating();
    }

    // ===================== Saving =====================
    private String writeJpeg(byte[] bytes, String name) {
        try {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            cv.put(MediaStore.Images.Media.RELATIVE_PATH, "DCIM/Story Lensa");
            cv.put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis());
            cv.put(MediaStore.Images.Media.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
            if (uri == null) return null;
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) return null;
                out.write(bytes);
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.Images.Media.IS_PENDING, 0);
            getContentResolver().update(uri, done, null, null);
            return uri.toString();
        } catch (Exception e) {
            return null;
        }
    }

    // ===================== Looks & shaders =====================
    static class Look {
        float[] g = {1, 1, 1}, m = {1, 0, 0, 0, 1, 0, 0, 0, 1}, mw = {.3f, .59f, .11f}, sh = {0, 0, 0}, hi = {0, 0, 0};
        float s = 1, mo = 0, vg = 0, gr = 0, ta = 0.75f, k = 1f;
        byte[] lut;

        static Look identity() {
            Look l = new Look();
            l.lut = new byte[4096];
            for (int i = 0; i < 1024; i++) {
                byte v = (byte) Math.round(i * 255f / 1023f);
                l.lut[i * 4] = v; l.lut[i * 4 + 1] = v; l.lut[i * 4 + 2] = v; l.lut[i * 4 + 3] = (byte) 255;
            }
            return l;
        }

        static float[] arr(JSONArray a, float[] def) {
            if (a == null || a.length() != def.length) return def;
            float[] o = new float[a.length()];
            for (int i = 0; i < o.length; i++) o[i] = (float) a.optDouble(i, 0);
            return o;
        }

        static Look parse(String json) {
            Look l = identity();
            try {
                JSONObject o = new JSONObject(json);
                l.g = arr(o.optJSONArray("g"), l.g);
                l.m = arr(o.optJSONArray("m"), l.m);
                l.mw = arr(o.optJSONArray("mw"), l.mw);
                l.sh = arr(o.optJSONArray("sh"), l.sh);
                l.hi = arr(o.optJSONArray("hi"), l.hi);
                l.s = (float) o.optDouble("s", 1);
                l.mo = (float) o.optDouble("mo", 0);
                l.vg = (float) o.optDouble("vg", 0);
                l.gr = (float) o.optDouble("gr", 0);
                l.ta = (float) o.optDouble("ta", 0.75);
                l.k = (float) o.optDouble("k", 1);
                String lut = o.optString("lut", "");
                if (!lut.isEmpty()) {
                    byte[] b = Base64.decode(lut, Base64.DEFAULT);
                    if (b.length == 4096) l.lut = b;
                }
            } catch (Exception ignored) {
            }
            return l;
        }
    }

    static final String VS = "attribute vec2 a;uniform mat4 ST;uniform vec4 C;varying vec2 v;varying vec2 vT;"
            + "void main(){v=a*.5+.5;vec2 u=C.xy+v*C.zw;vT=(ST*vec4(u,0.,1.)).xy;gl_Position=vec4(a,0.,1.);}";

    static String fs(boolean ext) {
        return (ext ? "#extension GL_OES_EGL_image_external : require\n" : "")
                + "precision highp float;varying vec2 v;varying vec2 vT;"
                + (ext ? "uniform samplerExternalOES T;" : "uniform sampler2D T;")
                + "uniform sampler2D L;uniform vec3 G;uniform mat3 M;uniform float S,MO,O,VG,GR,TM,RAD,K;uniform vec3 MW,SH,HI;uniform vec2 R;"
                + "float h(vec2 p){p=fract(p*vec2(443.897,441.423));p+=dot(p,p.yx+19.19);return fract((p.x+p.y)*p.x);}"
                + "vec3 lut(vec3 c){c=clamp(c,0.,1.)*(1023./1024.)+.5/1024.;return vec3(texture2D(L,vec2(c.r,.5)).r,texture2D(L,vec2(c.g,.5)).g,texture2D(L,vec2(c.b,.5)).b);}"
                + "void main(){vec3 c0=texture2D(T,vT).rgb;vec3 c=c0;"
                + "if(O<.5){vec3 b=c0*G;c=M*b;"
                + "if(MO>.5){c=vec3(dot(c,MW));}else{float l=dot(c,vec3(.2126,.7152,.0722));c=l+(c-l)*S;}"
                + "c=lut(c);"
                + "float l2=dot(c,vec3(.2126,.7152,.0722));c+=SH*(1.-l2)*(1.-l2)+HI*l2*l2;"
                + "if(MO<.5){float cb=-.1687*b.r-.3313*b.g+.5*b.b;float cr=.5*b.r-.4187*b.g-.0813*b.b;"
                + "float an=atan(cr,-cb+1e-5)-.85;float sk=exp(-an*an/.144)*smoothstep(.015,.05,length(vec2(cb,cr)))*step(0.,cr);"
                + "c=mix(c,lut(b),sk*.4);}"
                + "vec2 d=(v-.5)*R;float q=dot(d,d)/(.25*dot(R,R));c*=1.-VG*q*q;"
                + "c=mix(c0,c,K);"
                + "if(GR>0.){c+=(h(gl_FragCoord.xy+TM)-.5)*GR*K*(1.2-abs(l2-.5));}}"
                + "c=clamp(c,0.,1.)+(h(gl_FragCoord.xy*1.37+TM*.37)-.5)/255.;"
                + "if(RAD>0.){vec2 pp=v*R;vec2 qq=abs(pp-R*.5)-(R*.5-RAD);float dd=length(max(qq,0.))-RAD;c*=clamp(.5-dd,0.,1.);}"
                + "gl_FragColor=vec4(clamp(c,0.,1.),1.);}";
    }

    static class GlProgram {
        int prog, aPos, uT, uL, uST, uC, uG, uM, uS, uMO, uO, uVG, uGR, uTM, uRAD, uK, uMW, uSH, uHI, uR;
        final java.nio.FloatBuffer quad;

        GlProgram(boolean ext) {
            prog = link(VS, fs(ext));
            aPos = android.opengl.GLES20.glGetAttribLocation(prog, "a");
            uT = u("T"); uL = u("L"); uST = u("ST"); uC = u("C"); uG = u("G"); uM = u("M"); uS = u("S"); uMO = u("MO");
            uO = u("O"); uVG = u("VG"); uGR = u("GR"); uTM = u("TM"); uRAD = u("RAD"); uK = u("K"); uMW = u("MW"); uSH = u("SH");
            uHI = u("HI"); uR = u("R");
            float[] q = {-1, -1, 1, -1, -1, 1, 1, 1};
            quad = java.nio.ByteBuffer.allocateDirect(q.length * 4).order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer();
            quad.put(q).position(0);
        }

        int u(String n) { return android.opengl.GLES20.glGetUniformLocation(prog, n); }

        static int compile(int type, String src) {
            int s = android.opengl.GLES20.glCreateShader(type);
            android.opengl.GLES20.glShaderSource(s, src);
            android.opengl.GLES20.glCompileShader(s);
            int[] ok = new int[1];
            android.opengl.GLES20.glGetShaderiv(s, android.opengl.GLES20.GL_COMPILE_STATUS, ok, 0);
            if (ok[0] == 0) throw new RuntimeException(android.opengl.GLES20.glGetShaderInfoLog(s));
            return s;
        }

        static int link(String vs, String fs) {
            int p = android.opengl.GLES20.glCreateProgram();
            android.opengl.GLES20.glAttachShader(p, compile(android.opengl.GLES20.GL_VERTEX_SHADER, vs));
            android.opengl.GLES20.glAttachShader(p, compile(android.opengl.GLES20.GL_FRAGMENT_SHADER, fs));
            android.opengl.GLES20.glLinkProgram(p);
            return p;
        }

        void draw(float[] st, float[] crop, Look l, boolean original, float rw, float rh, float radius, float grainScale) {
            android.opengl.GLES20.glUseProgram(prog);
            android.opengl.GLES20.glVertexAttribPointer(aPos, 2, android.opengl.GLES20.GL_FLOAT, false, 0, quad);
            android.opengl.GLES20.glEnableVertexAttribArray(aPos);
            android.opengl.GLES20.glUniform1i(uT, 0);
            android.opengl.GLES20.glUniform1i(uL, 1);
            android.opengl.GLES20.glUniformMatrix4fv(uST, 1, false, st, 0);
            android.opengl.GLES20.glUniform4f(uC, crop[0], crop[1], crop[2], crop[3]);
            android.opengl.GLES20.glUniform3f(uG, l.g[0], l.g[1], l.g[2]);
            android.opengl.GLES20.glUniformMatrix3fv(uM, 1, false, l.m, 0);
            android.opengl.GLES20.glUniform1f(uS, l.s);
            android.opengl.GLES20.glUniform1f(uMO, l.mo);
            android.opengl.GLES20.glUniform1f(uO, original ? 1f : 0f);
            android.opengl.GLES20.glUniform1f(uVG, l.vg);
            android.opengl.GLES20.glUniform1f(uGR, l.gr * grainScale);
            android.opengl.GLES20.glUniform1f(uTM, (float) (Math.random() * 999));
            android.opengl.GLES20.glUniform1f(uRAD, radius);
            android.opengl.GLES20.glUniform1f(uK, l.k);
            android.opengl.GLES20.glUniform3f(uMW, l.mw[0], l.mw[1], l.mw[2]);
            android.opengl.GLES20.glUniform3f(uSH, l.sh[0], l.sh[1], l.sh[2]);
            android.opengl.GLES20.glUniform3f(uHI, l.hi[0], l.hi[1], l.hi[2]);
            android.opengl.GLES20.glUniform2f(uR, rw, rh);
            android.opengl.GLES20.glDrawArrays(android.opengl.GLES20.GL_TRIANGLE_STRIP, 0, 4);
        }
    }

    static int newTexture(int target) {
        int[] t = new int[1];
        android.opengl.GLES20.glGenTextures(1, t, 0);
        android.opengl.GLES20.glBindTexture(target, t[0]);
        android.opengl.GLES20.glTexParameteri(target, android.opengl.GLES20.GL_TEXTURE_MIN_FILTER, android.opengl.GLES20.GL_LINEAR);
        android.opengl.GLES20.glTexParameteri(target, android.opengl.GLES20.GL_TEXTURE_MAG_FILTER, android.opengl.GLES20.GL_LINEAR);
        android.opengl.GLES20.glTexParameteri(target, android.opengl.GLES20.GL_TEXTURE_WRAP_S, android.opengl.GLES20.GL_CLAMP_TO_EDGE);
        android.opengl.GLES20.glTexParameteri(target, android.opengl.GLES20.GL_TEXTURE_WRAP_T, android.opengl.GLES20.GL_CLAMP_TO_EDGE);
        return t[0];
    }

    static void uploadLut(int tex, byte[] lut) {
        java.nio.ByteBuffer b = java.nio.ByteBuffer.allocateDirect(4096);
        b.put(lut).position(0);
        android.opengl.GLES20.glActiveTexture(android.opengl.GLES20.GL_TEXTURE1);
        android.opengl.GLES20.glBindTexture(android.opengl.GLES20.GL_TEXTURE_2D, tex);
        android.opengl.GLES20.glTexImage2D(android.opengl.GLES20.GL_TEXTURE_2D, 0, android.opengl.GLES20.GL_RGBA, 1024, 1, 0,
                android.opengl.GLES20.GL_RGBA, android.opengl.GLES20.GL_UNSIGNED_BYTE, b);
    }

    static float[] cropFor(float bufA, float target) {
        if (target <= 0) return new float[]{0, 0, 1, 1};
        if (target < bufA) {
            float sx = target / bufA;
            return new float[]{(1 - sx) / 2, 0, sx, 1};
        } else {
            float sy = bufA / target;
            return new float[]{0, (1 - sy) / 2, 1, sy};
        }
    }

    static float grainScale(float w) { return Math.min(1.5f, Math.max(0.6f, w / 1500f)); }

    // ===================== Live preview renderer =====================
    class PreviewRenderer implements GLSurfaceView.Renderer {
        GlProgram prog;
        int oesTex, lutTex;
        Look lastLook;
        int surfW, surfH;
        final float[] stm = new float[16];

        @Override
        public void onSurfaceCreated(javax.microedition.khronos.opengles.GL10 gl, javax.microedition.khronos.egl.EGLConfig cfg) {
            prog = new GlProgram(true);
            oesTex = newTexture(android.opengl.GLES11Ext.GL_TEXTURE_EXTERNAL_OES);
            lutTex = newTexture(android.opengl.GLES20.GL_TEXTURE_2D);
            lastLook = null;
            android.opengl.Matrix.setIdentityM(stm, 0);
            SurfaceTexture old = surfaceTexture;
            SurfaceTexture st = new SurfaceTexture(oesTex);
            st.setOnFrameAvailableListener(t -> glView.requestRender());
            surfaceTexture = st;
            main.post(() -> {
                camH.post(() -> closeCamera());
                if (old != null) camH.post(old::release);
                startCameraIfReady();
            });
        }

        @Override
        public void onSurfaceChanged(javax.microedition.khronos.opengles.GL10 gl, int w, int h) {
            surfW = w;
            surfH = h;
        }

        @Override
        public void onDrawFrame(javax.microedition.khronos.opengles.GL10 gl) {
            SurfaceTexture st = surfaceTexture;
            if (st != null) {
                try {
                    st.updateTexImage();
                    st.getTransformMatrix(stm);
                } catch (Exception ignored) {
                }
            }
            android.opengl.GLES20.glViewport(0, 0, surfW, surfH);
            android.opengl.GLES20.glClearColor(0, 0, 0, 1);
            android.opengl.GLES20.glClear(android.opengl.GLES20.GL_COLOR_BUFFER_BIT);
            float[] r = vfRect;
            Look l = look;
            if (r == null || l == null || !camReady) return;
            int x = Math.round(r[0]), w = Math.round(r[2]), h = Math.round(r[3]);
            int y = surfH - Math.round(r[1] + r[3]);
            android.opengl.GLES20.glViewport(x, y, w, h);
            if (l != lastLook) { uploadLut(lutTex, l.lut); lastLook = l; }
            android.opengl.GLES20.glActiveTexture(android.opengl.GLES20.GL_TEXTURE1);
            android.opengl.GLES20.glBindTexture(android.opengl.GLES20.GL_TEXTURE_2D, lutTex);
            android.opengl.GLES20.glActiveTexture(android.opengl.GLES20.GL_TEXTURE0);
            android.opengl.GLES20.glBindTexture(android.opengl.GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTex);
            prog.draw(stm, cropFor(bufAspect, l.ta), l, showOriginal, w, h, r[4], grainScale(w));
        }
    }

    // ===================== Full-resolution processing (own EGL context) =====================
    class Processor {
        final HandlerThread t = new HandlerThread("process");
        final Handler h;
        android.opengl.EGLDisplay dpy;
        android.opengl.EGLContext ctx;
        android.opengl.EGLSurface surf;
        GlProgram prog;
        int maxTex = 4096;
        boolean ready = false;

        Processor() {
            t.start();
            h = new Handler(t.getLooper());
            h.post(this::init);
        }

        void init() {
            try {
                dpy = android.opengl.EGL14.eglGetDisplay(android.opengl.EGL14.EGL_DEFAULT_DISPLAY);
                int[] ver = new int[2];
                android.opengl.EGL14.eglInitialize(dpy, ver, 0, ver, 1);
                int[] attr = {android.opengl.EGL14.EGL_RED_SIZE, 8, android.opengl.EGL14.EGL_GREEN_SIZE, 8,
                        android.opengl.EGL14.EGL_BLUE_SIZE, 8, android.opengl.EGL14.EGL_ALPHA_SIZE, 8,
                        android.opengl.EGL14.EGL_RENDERABLE_TYPE, android.opengl.EGL14.EGL_OPENGL_ES2_BIT,
                        android.opengl.EGL14.EGL_SURFACE_TYPE, android.opengl.EGL14.EGL_PBUFFER_BIT, android.opengl.EGL14.EGL_NONE};
                android.opengl.EGLConfig[] cfg = new android.opengl.EGLConfig[1];
                int[] n = new int[1];
                android.opengl.EGL14.eglChooseConfig(dpy, attr, 0, cfg, 0, 1, n, 0);
                ctx = android.opengl.EGL14.eglCreateContext(dpy, cfg[0], android.opengl.EGL14.EGL_NO_CONTEXT,
                        new int[]{android.opengl.EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, android.opengl.EGL14.EGL_NONE}, 0);
                surf = android.opengl.EGL14.eglCreatePbufferSurface(dpy, cfg[0],
                        new int[]{android.opengl.EGL14.EGL_WIDTH, 1, android.opengl.EGL14.EGL_HEIGHT, 1, android.opengl.EGL14.EGL_NONE}, 0);
                android.opengl.EGL14.eglMakeCurrent(dpy, surf, surf, ctx);
                prog = new GlProgram(false);
                int[] mt = new int[1];
                android.opengl.GLES20.glGetIntegerv(android.opengl.GLES20.GL_MAX_TEXTURE_SIZE, mt, 0);
                maxTex = Math.max(2048, Math.min(mt[0], 8192));
                ready = true;
            } catch (Exception e) {
                ready = false;
            }
        }

        void quit() {
            h.post(() -> {
                try {
                    android.opengl.EGL14.eglMakeCurrent(dpy, android.opengl.EGL14.EGL_NO_SURFACE, android.opengl.EGL14.EGL_NO_SURFACE, android.opengl.EGL14.EGL_NO_CONTEXT);
                    android.opengl.EGL14.eglDestroySurface(dpy, surf);
                    android.opengl.EGL14.eglDestroyContext(dpy, ctx);
                    android.opengl.EGL14.eglTerminate(dpy);
                } catch (Exception ignored) {
                }
                t.quitSafely();
            });
        }

        void submit(final byte[] jpeg, final Shot shot) {
            h.post(() -> {
                String uri = null;
                String thumb = "";
                try {
                    Bitmap bmp = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.length);
                    int rot = 0;
                    try {
                        ExifInterface ex = new ExifInterface(new ByteArrayInputStream(jpeg));
                        int o = ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                        if (o == ExifInterface.ORIENTATION_ROTATE_90) rot = 90;
                        else if (o == ExifInterface.ORIENTATION_ROTATE_180) rot = 180;
                        else if (o == ExifInterface.ORIENTATION_ROTATE_270) rot = 270;
                    } catch (Exception ignored) {
                    }
                    float down = Math.min(1f, (float) maxTex / Math.max(bmp.getWidth(), bmp.getHeight()));
                    if (rot != 0 || down < 1f) {
                        Matrix m = new Matrix();
                        if (rot != 0) m.postRotate(rot);
                        if (down < 1f) m.postScale(down, down);
                        Bitmap r = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
                        if (r != bmp) bmp.recycle();
                        bmp = r;
                    }
                    Bitmap out = ready ? render(bmp, shot) : bmp;
                    if (out != bmp) bmp.recycle();
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    out.compress(Bitmap.CompressFormat.JPEG, 95, bos);
                    uri = writeJpeg(bos.toByteArray(), shot.name);
                    float ts = 180f / Math.max(out.getWidth(), out.getHeight());
                    Bitmap small = Bitmap.createScaledBitmap(out, Math.max(1, Math.round(out.getWidth() * ts)), Math.max(1, Math.round(out.getHeight() * ts)), true);
                    ByteArrayOutputStream tb = new ByteArrayOutputStream();
                    small.compress(Bitmap.CompressFormat.JPEG, 80, tb);
                    thumb = "data:image/jpeg;base64," + Base64.encodeToString(tb.toByteArray(), Base64.NO_WRAP);
                    small.recycle();
                    out.recycle();
                } catch (Throwable e) {
                    uri = null;
                }
                try {
                    JSONObject o = new JSONObject();
                    o.put("ok", uri != null);
                    o.put("uri", uri == null ? "" : uri);
                    o.put("thumb", thumb);
                    emit("saved", o.toString());
                } catch (Exception ignored) {
                }
            });
        }

        Bitmap render(Bitmap src, Shot shot) {
            int w = src.getWidth(), hh = src.getHeight();
            float ba = (float) w / hh;
            float ta = shot.look.ta;
            if (w > hh && ta < 1f) ta = 1f / ta;
            float[] c = cropFor(ba, ta);
            if (shot.front) c = new float[]{c[0] + c[2], c[1], -c[2], c[3]};
            int outW = Math.max(1, Math.round(w * Math.abs(c[2])));
            int outH = Math.max(1, Math.round(hh * c[3]));
            float s = Math.min(1f, (float) Math.sqrt(16e6 / ((double) outW * outH)));
            outW = Math.max(1, Math.round(outW * s));
            outH = Math.max(1, Math.round(outH * s));

            int srcTex = newTexture(android.opengl.GLES20.GL_TEXTURE_2D);
            android.opengl.GLUtils.texImage2D(android.opengl.GLES20.GL_TEXTURE_2D, 0, src, 0);
            int lutTex = newTexture(android.opengl.GLES20.GL_TEXTURE_2D);
            uploadLut(lutTex, shot.look.lut);
            int dstTex = newTexture(android.opengl.GLES20.GL_TEXTURE_2D);
            android.opengl.GLES20.glTexImage2D(android.opengl.GLES20.GL_TEXTURE_2D, 0, android.opengl.GLES20.GL_RGBA, outW, outH, 0,
                    android.opengl.GLES20.GL_RGBA, android.opengl.GLES20.GL_UNSIGNED_BYTE, null);
            int[] fbo = new int[1];
            android.opengl.GLES20.glGenFramebuffers(1, fbo, 0);
            android.opengl.GLES20.glBindFramebuffer(android.opengl.GLES20.GL_FRAMEBUFFER, fbo[0]);
            android.opengl.GLES20.glFramebufferTexture2D(android.opengl.GLES20.GL_FRAMEBUFFER, android.opengl.GLES20.GL_COLOR_ATTACHMENT0,
                    android.opengl.GLES20.GL_TEXTURE_2D, dstTex, 0);
            android.opengl.GLES20.glViewport(0, 0, outW, outH);
            android.opengl.GLES20.glActiveTexture(android.opengl.GLES20.GL_TEXTURE1);
            android.opengl.GLES20.glBindTexture(android.opengl.GLES20.GL_TEXTURE_2D, lutTex);
            android.opengl.GLES20.glActiveTexture(android.opengl.GLES20.GL_TEXTURE0);
            android.opengl.GLES20.glBindTexture(android.opengl.GLES20.GL_TEXTURE_2D, srcTex);
            float[] ident = new float[16];
            android.opengl.Matrix.setIdentityM(ident, 0);
            prog.draw(ident, c, shot.look, false, outW, outH, 0f, grainScale(outW));
            java.nio.ByteBuffer buf = java.nio.ByteBuffer.allocateDirect(outW * outH * 4).order(java.nio.ByteOrder.nativeOrder());
            android.opengl.GLES20.glReadPixels(0, 0, outW, outH, android.opengl.GLES20.GL_RGBA, android.opengl.GLES20.GL_UNSIGNED_BYTE, buf);
            android.opengl.GLES20.glBindFramebuffer(android.opengl.GLES20.GL_FRAMEBUFFER, 0);
            android.opengl.GLES20.glDeleteFramebuffers(1, fbo, 0);
            android.opengl.GLES20.glDeleteTextures(3, new int[]{srcTex, lutTex, dstTex}, 0);
            Bitmap out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888);
            buf.rewind();
            out.copyPixelsFromBuffer(buf);
            return out;
        }
    }

    // ===================== JS bridge =====================
    private class Bridge {
        @JavascriptInterface
        public boolean nativeCamera() { return true; }

        @JavascriptInterface
        public String version() { return VERSION; }

        @JavascriptInterface
        public void setViewfinder(double x, double y, double w, double h, double r) {
            float d = getResources().getDisplayMetrics().density;
            vfRect = new float[]{(float) (x * d), (float) (y * d), (float) (w * d), (float) (h * d), (float) (r * d)};
            glView.requestRender();
        }

        @JavascriptInterface
        public void setLook(String json) {
            look = Look.parse(json);
            glView.requestRender();
        }

        @JavascriptInterface
        public void setOriginal(boolean on) {
            showOriginal = on;
            glView.requestRender();
        }

        @JavascriptInterface
        public void selectLens(final int i) {
            camH.post(() -> {
                if (i < 0 || i >= lenses.size()) return;
                Lens l = lenses.get(i);
                lensIdx = i;
                pinch = 1f;
                if (!l.camId.equals(camId) || device == null) openCamera(l.camId);
                else updateRepeating();
            });
        }

        @JavascriptInterface
        public void setPinch(final double p) {
            camH.post(() -> {
                pinch = (float) Math.max(1.0, p);
                updateRepeating();
            });
        }

        @JavascriptInterface
        public void focusAt(final double nx, final double ny) {
            camH.post(() -> MainActivity.this.focusAt((float) nx, (float) ny));
        }

        @JavascriptInterface
        public void setLock(final boolean on) {
            camH.post(() -> {
                aeAfLock = on;
                if (on) camH.removeCallbacks(regionReset);
                updateRepeating();
            });
        }

        @JavascriptInterface
        public void setExposure(final double ev) {
            camH.post(() -> {
                evValue = (float) ev;
                updateRepeating();
            });
        }

        @JavascriptInterface
        public void setFlash(final int mode) {
            camH.post(() -> {
                flashMode = Math.max(0, Math.min(2, mode));
                updateRepeating();
            });
        }

        @JavascriptInterface
        public void setManual(final String json) {
            camH.post(() -> {
                try {
                    JSONObject o = new JSONObject(json);
                    int iso = o.optInt("iso", 0);
                    long exp = o.optLong("exp", 0);
                    manualIso = manualSensor && iso > 0 ? isoRange.clamp(iso) : 0;
                    manualExp = manualSensor && exp > 0 ? expRange.clamp(exp) : 0;
                    int wb = o.optInt("wb", CaptureRequest.CONTROL_AWB_MODE_AUTO);
                    boolean ok = false;
                    for (int m : awbModes) if (m == wb) ok = true;
                    awbMode = ok ? wb : CaptureRequest.CONTROL_AWB_MODE_AUTO;
                    double mf = o.optDouble("mf", -1);
                    manualFocus = (mf >= 0 && minFocus > 0 && manualSensor) ? (float) Math.min(1, mf) : -1f;
                    if (manualFocus >= 0) regions = null;
                    updateRepeating();
                } catch (Exception ignored) {
                }
            });
        }

        @JavascriptInterface
        public void capture(final String name) {
            main.post(() -> web.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY));
            camH.post(() -> MainActivity.this.capture(name));
        }

        @JavascriptInterface
        public void flip() {
            camH.post(() -> {
                List<Lens> next = buildLenses(!front);
                if (next.isEmpty()) { emit("error", "{\"msg\":\"Kamera lain tidak tersedia\"}"); sendCameraEvent(); return; }
                front = !front;
                lenses = next;
                lensIdx = mainLensIndex();
                pinch = 1f;
                openCamera(lenses.get(lensIdx).camId);
            });
        }

        @JavascriptInterface
        public void openUri(final String uri) {
            main.post(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setDataAndType(Uri.parse(uri), "image/*");
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Exception ignored) {
                }
            });
        }

        @JavascriptInterface
        public void haptic() {
            main.post(() -> web.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY));
        }
    }
}
